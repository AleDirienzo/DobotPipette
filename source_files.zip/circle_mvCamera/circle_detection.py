import sensor, image, time
from pyb import UART

# Initialise the camera
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)  # Set a lower resolution for a smaller field of view
sensor.skip_frames(time=2000)
clock = time.clock()

# Initialise UART communication
uart = UART(3, 9600)  # UART 3, 9600 baud rate

while(True):
    clock.tick()
    img = sensor.snapshot()

    # Detect circles
    circles = img.find_circles(threshold=3000, x_margin=20, y_margin=20, r_margin=20,
                               r_min=30, r_max=100, r_step=2)

    # Filter and find the circle closest to the centre
    if circles:
        center_x, center_y = img.width() // 2, img.height() // 2
        img.draw_cross(center_x, center_y, color=(255, 0, 0), size=10)
        closest_circle = min(circles, key=lambda c: (c.x() - center_x)**2 + (c.y() - center_y)**2)
        img.draw_circle(closest_circle.x(), closest_circle.y(), closest_circle.r(), color=(255, 0, 0))

        # Draw a cross in the centre of the circle
        img.draw_cross(closest_circle.x(), closest_circle.y(), color=(0, 255, 0), size=10)

        # Send circle co-ordinates via UART
        uart.write("{},{},{}\n".format(closest_circle.x()- center_x, closest_circle.y()- center_y, closest_circle.r()))

        print("{},{},{}\n".format(closest_circle.x()-center_x, closest_circle.y()- center_y, closest_circle.r()))

        time.sleep(0.1)





